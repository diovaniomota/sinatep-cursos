import '/flutter_flow/flutter_flow_util.dart';
import 'drawer_widget.dart' show DrawerWidget;
import 'package:flutter/material.dart';

class DrawerModel extends FlutterFlowModel<DrawerWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
