import '/backend/custom_cloud_functions/custom_cloud_function_response_manager.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'gerenciar_usuario_page_widget.dart' show GerenciarUsuarioPageWidget;
import 'package:flutter/material.dart';

class GerenciarUsuarioPageModel
    extends FlutterFlowModel<GerenciarUsuarioPageWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  // Stores action output result for [Cloud Function - gerenciarUsuario] action in IconButton widget.
  GerenciarUsuarioCloudFunctionCallResponse? cloudFunctionAlterar;
  // Stores action output result for [Cloud Function - gerenciarUsuario] action in IconButton widget.
  GerenciarUsuarioCloudFunctionCallResponse? cloudFunctionCriar;
  // State field(s) for Nome widget.
  FocusNode? nomeFocusNode;
  TextEditingController? nomeController;
  String? Function(BuildContext, String?)? nomeControllerValidator;
  String? _nomeControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    if (val.length < 2) {
      return 'Requires at least 2 characters.';
    }

    return null;
  }

  // State field(s) for Email widget.
  FocusNode? emailFocusNode;
  TextEditingController? emailController;
  String? Function(BuildContext, String?)? emailControllerValidator;
  String? _emailControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    if (!RegExp(kTextValidatorEmailRegex).hasMatch(val)) {
      return 'Has to be a valid email address.';
    }
    return null;
  }

  // State field(s) for RedefinirSenha widget.
  bool? redefinirSenhaValue;
  // State field(s) for NovaSenha widget.
  FocusNode? novaSenhaFocusNode;
  TextEditingController? novaSenhaController;
  late bool novaSenhaVisibility;
  String? Function(BuildContext, String?)? novaSenhaControllerValidator;
  String? _novaSenhaControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    if (val.length < 6) {
      return 'Requires at least 6 characters.';
    }

    return null;
  }

  // State field(s) for Senha widget.
  FocusNode? senhaFocusNode;
  TextEditingController? senhaController;
  late bool senhaVisibility;
  String? Function(BuildContext, String?)? senhaControllerValidator;
  String? _senhaControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    if (val.length < 6) {
      return 'Requires at least 6 characters.';
    }

    return null;
  }

  @override
  void initState(BuildContext context) {
    nomeControllerValidator = _nomeControllerValidator;
    emailControllerValidator = _emailControllerValidator;
    novaSenhaVisibility = false;
    novaSenhaControllerValidator = _novaSenhaControllerValidator;
    senhaVisibility = false;
    senhaControllerValidator = _senhaControllerValidator;
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    nomeFocusNode?.dispose();
    nomeController?.dispose();

    emailFocusNode?.dispose();
    emailController?.dispose();

    novaSenhaFocusNode?.dispose();
    novaSenhaController?.dispose();

    senhaFocusNode?.dispose();
    senhaController?.dispose();
  }
}
