import '/flutter_flow/flutter_flow_util.dart';
import 'redefinir_senha_page_widget.dart' show RedefinirSenhaPageWidget;
import 'package:flutter/material.dart';

class RedefinirSenhaPageModel
    extends FlutterFlowModel<RedefinirSenhaPageWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  // State field(s) for NovaSenha widget.
  FocusNode? novaSenhaFocusNode;
  TextEditingController? novaSenhaController;
  late bool novaSenhaVisibility;
  String? Function(BuildContext, String?)? novaSenhaControllerValidator;
  String? _novaSenhaControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    if (val.length < 6) {
      return 'Requires at least 6 characters.';
    }

    return null;
  }

  // State field(s) for ConfirmarSenha widget.
  FocusNode? confirmarSenhaFocusNode;
  TextEditingController? confirmarSenhaController;
  late bool confirmarSenhaVisibility;
  String? Function(BuildContext, String?)? confirmarSenhaControllerValidator;
  String? _confirmarSenhaControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    if (val.length < 6) {
      return 'Requires at least 6 characters.';
    }

    return null;
  }

  // Stores action output result for [Custom Action - updatePassword] action in Enviar widget.
  bool? sucesso;

  @override
  void initState(BuildContext context) {
    novaSenhaVisibility = false;
    novaSenhaControllerValidator = _novaSenhaControllerValidator;
    confirmarSenhaVisibility = false;
    confirmarSenhaControllerValidator = _confirmarSenhaControllerValidator;
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    novaSenhaFocusNode?.dispose();
    novaSenhaController?.dispose();

    confirmarSenhaFocusNode?.dispose();
    confirmarSenhaController?.dispose();
  }
}
