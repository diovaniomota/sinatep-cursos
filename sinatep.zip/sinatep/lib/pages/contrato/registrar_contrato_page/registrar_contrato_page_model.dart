import '/backend/backend.dart';
import '/backend/custom_cloud_functions/custom_cloud_function_response_manager.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import 'registrar_contrato_page_widget.dart' show RegistrarContratoPageWidget;
import 'package:flutter/material.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';

class RegistrarContratoPageModel
    extends FlutterFlowModel<RegistrarContratoPageWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  // State field(s) for Contratante widget.
  FocusNode? contratanteFocusNode;
  TextEditingController? contratanteController;
  String? Function(BuildContext, String?)? contratanteControllerValidator;
  // State field(s) for Documento widget.
  FocusNode? documentoFocusNode;
  TextEditingController? documentoController;
  final documentoMask = MaskTextInputFormatter(mask: '###.###.###-##');
  String? Function(BuildContext, String?)? documentoControllerValidator;
  // State field(s) for RG widget.
  FocusNode? rgFocusNode;
  TextEditingController? rgController;
  final rgMask = MaskTextInputFormatter(mask: '##.###.###-#');
  String? Function(BuildContext, String?)? rgControllerValidator;
  // State field(s) for DN widget.
  FocusNode? dnFocusNode;
  TextEditingController? dnController;
  final dnMask = MaskTextInputFormatter(mask: '##/##/####');
  String? Function(BuildContext, String?)? dnControllerValidator;
  // State field(s) for Filiacao widget.
  FocusNode? filiacaoFocusNode;
  TextEditingController? filiacaoController;
  String? Function(BuildContext, String?)? filiacaoControllerValidator;
  // State field(s) for Naturalidade widget.
  FocusNode? naturalidadeFocusNode;
  TextEditingController? naturalidadeController;
  String? Function(BuildContext, String?)? naturalidadeControllerValidator;
  // State field(s) for Sexo widget.
  String? sexoValue;
  FormFieldController<String>? sexoValueController;
  // State field(s) for Endereco widget.
  FocusNode? enderecoFocusNode;
  TextEditingController? enderecoController;
  String? Function(BuildContext, String?)? enderecoControllerValidator;
  // State field(s) for Numero widget.
  FocusNode? numeroFocusNode;
  TextEditingController? numeroController;
  String? Function(BuildContext, String?)? numeroControllerValidator;
  // State field(s) for Bairro widget.
  FocusNode? bairroFocusNode;
  TextEditingController? bairroController;
  String? Function(BuildContext, String?)? bairroControllerValidator;
  // State field(s) for Cidade widget.
  FocusNode? cidadeFocusNode;
  TextEditingController? cidadeController;
  String? Function(BuildContext, String?)? cidadeControllerValidator;
  // State field(s) for CEP widget.
  FocusNode? cepFocusNode;
  TextEditingController? cepController;
  final cepMask = MaskTextInputFormatter(mask: '#####-###');
  String? Function(BuildContext, String?)? cepControllerValidator;
  // State field(s) for UF widget.
  FocusNode? ufFocusNode;
  TextEditingController? ufController;
  final ufMask = MaskTextInputFormatter(mask: 'AA');
  String? Function(BuildContext, String?)? ufControllerValidator;
  // State field(s) for Telefones widget.
  FocusNode? telefonesFocusNode;
  TextEditingController? telefonesController;
  String? Function(BuildContext, String?)? telefonesControllerValidator;
  // State field(s) for Aluno widget.
  FocusNode? alunoFocusNode;
  TextEditingController? alunoController;
  String? Function(BuildContext, String?)? alunoControllerValidator;
  // State field(s) for AlunoDN widget.
  FocusNode? alunoDNFocusNode;
  TextEditingController? alunoDNController;
  final alunoDNMask = MaskTextInputFormatter(mask: '##/##/####');
  String? Function(BuildContext, String?)? alunoDNControllerValidator;
  // State field(s) for AlunoDocumento widget.
  FocusNode? alunoDocumentoFocusNode;
  TextEditingController? alunoDocumentoController;
  String? Function(BuildContext, String?)? alunoDocumentoControllerValidator;
  // State field(s) for AlunoNaturalidade widget.
  FocusNode? alunoNaturalidadeFocusNode;
  TextEditingController? alunoNaturalidadeController;
  String? Function(BuildContext, String?)? alunoNaturalidadeControllerValidator;
  // State field(s) for AlunoTelefone widget.
  FocusNode? alunoTelefoneFocusNode;
  TextEditingController? alunoTelefoneController;
  final alunoTelefoneMask = MaskTextInputFormatter(mask: '(##) #####-####');
  String? Function(BuildContext, String?)? alunoTelefoneControllerValidator;
  // State field(s) for OpcaoCurso widget.
  String? opcaoCursoValue;
  FormFieldController<String>? opcaoCursoValueController;
  // State field(s) for Outro widget.
  FocusNode? outroFocusNode;
  TextEditingController? outroController;
  String? Function(BuildContext, String?)? outroControllerValidator;
  // State field(s) for Indicacao widget.
  FocusNode? indicacaoFocusNode;
  TextEditingController? indicacaoController;
  String? Function(BuildContext, String?)? indicacaoControllerValidator;
  // State field(s) for Horas widget.
  FocusNode? horasFocusNode;
  TextEditingController? horasController;
  String? Function(BuildContext, String?)? horasControllerValidator;
  // State field(s) for InicioPrevisto widget.
  FocusNode? inicioPrevistoFocusNode;
  TextEditingController? inicioPrevistoController;
  final inicioPrevistoMask = MaskTextInputFormatter(mask: '##/##');
  String? Function(BuildContext, String?)? inicioPrevistoControllerValidator;
  // State field(s) for Contratada widget.
  FocusNode? contratadaFocusNode;
  TextEditingController? contratadaController;
  String? Function(BuildContext, String?)? contratadaControllerValidator;
  // State field(s) for PagementoOp3 widget.
  String? pagementoOp3Value;
  FormFieldController<String>? pagementoOp3ValueController;
  // State field(s) for Pagemento widget.
  String? pagementoValue;
  FormFieldController<String>? pagementoValueController;
  // State field(s) for PrimeiraParcela widget.
  FocusNode? primeiraParcelaFocusNode;
  TextEditingController? primeiraParcelaController;
  final primeiraParcelaMask = MaskTextInputFormatter(mask: '##/##/####');
  String? Function(BuildContext, String?)? primeiraParcelaControllerValidator;
  // State field(s) for Desconto widget.
  FocusNode? descontoFocusNode;
  TextEditingController? descontoController;
  String? Function(BuildContext, String?)? descontoControllerValidator;
  // Stores action output result for [Firestore Query - Query a collection] action in Gerar widget.
  int? count;
  // Stores action output result for [Backend Call - Create Document] action in Gerar widget.
  ContratoRecord? contratoDoc;
  // Stores action output result for [Cloud Function - criarPDF] action in Gerar widget.
  CriarPDFCloudFunctionCallResponse? func01;
  // Stores action output result for [Cloud Function - escreverPDF] action in Gerar widget.
  EscreverPDFCloudFunctionCallResponse? func02;
  // Stores action output result for [Cloud Function - deletarPDF] action in Gerar widget.
  DeletarPDFCloudFunctionCallResponse? cloudFunctionq93;
  // Stores action output result for [Cloud Function - criarPDF] action in Gerar widget.
  CriarPDFCloudFunctionCallResponse? cloudFunctions6g;
  // Stores action output result for [Cloud Function - escreverPDF] action in Gerar widget.
  EscreverPDFCloudFunctionCallResponse? cloudFunctionf9l;
  // Stores action output result for [Cloud Function - assinarContrato] action in Gerar widget.
  AssinarContratoCloudFunctionCallResponse? cloudFunctionap7;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    contratanteFocusNode?.dispose();
    contratanteController?.dispose();

    documentoFocusNode?.dispose();
    documentoController?.dispose();

    rgFocusNode?.dispose();
    rgController?.dispose();

    dnFocusNode?.dispose();
    dnController?.dispose();

    filiacaoFocusNode?.dispose();
    filiacaoController?.dispose();

    naturalidadeFocusNode?.dispose();
    naturalidadeController?.dispose();

    enderecoFocusNode?.dispose();
    enderecoController?.dispose();

    numeroFocusNode?.dispose();
    numeroController?.dispose();

    bairroFocusNode?.dispose();
    bairroController?.dispose();

    cidadeFocusNode?.dispose();
    cidadeController?.dispose();

    cepFocusNode?.dispose();
    cepController?.dispose();

    ufFocusNode?.dispose();
    ufController?.dispose();

    telefonesFocusNode?.dispose();
    telefonesController?.dispose();

    alunoFocusNode?.dispose();
    alunoController?.dispose();

    alunoDNFocusNode?.dispose();
    alunoDNController?.dispose();

    alunoDocumentoFocusNode?.dispose();
    alunoDocumentoController?.dispose();

    alunoNaturalidadeFocusNode?.dispose();
    alunoNaturalidadeController?.dispose();

    alunoTelefoneFocusNode?.dispose();
    alunoTelefoneController?.dispose();

    outroFocusNode?.dispose();
    outroController?.dispose();

    indicacaoFocusNode?.dispose();
    indicacaoController?.dispose();

    horasFocusNode?.dispose();
    horasController?.dispose();

    inicioPrevistoFocusNode?.dispose();
    inicioPrevistoController?.dispose();

    contratadaFocusNode?.dispose();
    contratadaController?.dispose();

    primeiraParcelaFocusNode?.dispose();
    primeiraParcelaController?.dispose();

    descontoFocusNode?.dispose();
    descontoController?.dispose();
  }
}
