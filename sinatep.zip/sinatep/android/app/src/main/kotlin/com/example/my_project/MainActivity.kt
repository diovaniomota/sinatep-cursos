package com.dartsoft.sinatep

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
